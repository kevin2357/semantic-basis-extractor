"""AstroWoof natal semantic-basis extraction and authoring runtime."""

from importlib.metadata import PackageNotFoundError, version
import logging


# Library consumers should not receive surprise stderr output merely by importing
# SBE.  Command entry points install the operational handler explicitly.
logging.getLogger(__name__).addHandler(logging.NullHandler())

try:
    __version__ = version("astrowoof-natal-authoring")
except PackageNotFoundError:
    __version__ = "0.4.0.dev0"

from .reconciliation import (  # noqa: E402
    ProviderReconciliationAdapters,
    reconcile_authoring_provider_cycle,
)
from .native_transitions import (  # noqa: E402
    NativeTransitionResultView,
    latest_native_transition_result,
    read_native_transition_result,
    validate_transition_journal,
)
from .route_parity import (  # noqa: E402
    read_bounded_route_parity_traces,
    read_route_parity_oracle,
    validate_bounded_route_traces,
    validate_route_parity_oracle,
)
from .initial_wave import (  # noqa: E402
    InitialWaveError,
    build_initial_wave_binding_bundle,
    build_wave_authorization,
    preflight_wave_authorization,
    validate_initial_wave,
    validate_initial_wave_binding_bundle,
    validate_initial_wave_binding_bundle_against_wave,
    validate_initial_wave_result,
    validate_wave_authorization_document,
)
from .initial_wave_contract import (  # noqa: E402
    build_initial_wave_authority_inputs,
    read_initial_wave_authority_inputs,
    read_initial_wave_fixture,
    read_initial_wave_schema,
    validate_initial_wave_fixture,
    validate_initial_wave_authority_inputs,
)
from .deployed_qa import (  # noqa: E402
    read_deployed_qa_schema,
    run_deployed_qa_qualification,
    validate_deployed_qa_receipt,
)
from .response_diagnostics import (  # noqa: E402
    inspect_response,
    read_response_retrieval_diagnostic_schema,
    validate_response_retrieval_diagnostic,
)

__all__ = [
    "NativeTransitionResultView",
    "ProviderReconciliationAdapters",
    "InitialWaveError",
    "__version__",
    "latest_native_transition_result",
    "build_initial_wave_authority_inputs",
    "build_initial_wave_binding_bundle",
    "build_wave_authorization",
    "preflight_wave_authorization",
    "read_initial_wave_fixture",
    "read_initial_wave_authority_inputs",
    "read_initial_wave_schema",
    "read_native_transition_result",
    "read_bounded_route_parity_traces",
    "read_route_parity_oracle",
    "read_deployed_qa_schema",
    "run_deployed_qa_qualification",
    "inspect_response",
    "read_response_retrieval_diagnostic_schema",
    "reconcile_authoring_provider_cycle",
    "validate_bounded_route_traces",
    "validate_initial_wave",
    "validate_initial_wave_authority_inputs",
    "validate_initial_wave_binding_bundle",
    "validate_initial_wave_binding_bundle_against_wave",
    "validate_initial_wave_fixture",
    "validate_initial_wave_result",
    "validate_wave_authorization_document",
    "validate_route_parity_oracle",
    "validate_deployed_qa_receipt",
    "validate_response_retrieval_diagnostic",
    "validate_transition_journal",
]
